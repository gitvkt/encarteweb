(function (root) {
  const config = Object.freeze({ topoMm: 80, larguraMm: 210, alturaMm: 297, larguraPx: 2480, alturaPx: 3508, mime: 'image/png', paginas: 1 });
  root.encarteOutput = config;
  root.desenharEncarte = function (lines, sizes) {
    const canvas = document.createElement('canvas');
    canvas.width = config.larguraPx; canvas.height = config.alturaPx;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Não foi possível gerar a imagem.');
    const ratio = config.larguraPx / (210 * 96 / 25.4);
    const height = (297 - config.topoMm - 12) * 96 / 25.4;
    const used = lines.reduce((sum, line) => sum + sizes[line.key] * 1.18, 0);
    const gap = (height - used) / (lines.length + 1);
    let y = config.topoMm * 96 / 25.4 + gap;
    // Canvas transparente: apenas tinta preta sobre o papel pré-impresso.
    ctx.fillStyle = '#000000';
    for (const line of lines) {
      const size = sizes[line.key];
      const font = line.font;
      const fontAt = s => `${font.italic ? 'italic ' : ''}${font.weight} ${s * ratio}px '${font.family}'`;
      ctx.font = fontAt(size); ctx.textBaseline = 'alphabetic';
      const metric = ctx.measureText(line.key === 'preco' ? line.text.replace(/^R\$ /, '') : line.text);
      const ascent = metric.fontBoundingBoxAscent || size * ratio;
      const descent = metric.fontBoundingBoxDescent || size * ratio * .2;
      const baseline = (y + size * 1.18 / 2) * ratio + (ascent - descent) / 2;
      if (line.key === 'preco') {
        const number = line.text.replace(/^R\$ /, '');
        const numberWidth = ctx.measureText(number).width;
        ctx.font = fontAt(size * .45);
        const prefixWidth = ctx.measureText('R$ ').width;
        const x = (canvas.width - numberWidth - prefixWidth) / 2;
        ctx.fillText('R$ ', x, baseline - size * ratio * .495);
        ctx.font = fontAt(size); ctx.fillText(number, x + prefixWidth, baseline);
      } else {
        const w = ctx.measureText(line.text).width;
        const x = line.key === 'peso' ? canvas.width - 12 * 96 / 25.4 * ratio - w : (canvas.width - w) / 2;
        ctx.fillText(line.text, x, baseline);
      }
      y += size * 1.18 + gap;
    }
    return canvas;
  };
})(globalThis);
