(function (root) {
  const unidades = ['kg', 'mg', 'g', 'ml', 'l', 'lt', 'cm', 'mm', 'm', 'un', 'und', 'pct', 'cx', 'dz'];
  const re = new RegExp('(\\d)(\\s*)(' + unidades.join('|') + ')\\b', 'gi');
  function formatar(texto) {
    return String(texto).toUpperCase().replace(re, (_, n, esp, u) => n + esp + u.toLowerCase());
  }
  root.formatarEncarte = formatar;
  if (typeof module !== 'undefined') module.exports = { formatar };
})(globalThis);
