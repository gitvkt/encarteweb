(() => {
  'use strict';
  const FONTES = {
    bebas: { nome: 'Bebas Neue', family: 'Bebas Neue', weight: 400 },
    impact: { nome: 'Impact (Anton)', family: 'Anton', weight: 400 },
    montserrat: { nome: 'Montserrat Black', family: 'Montserrat', weight: 900 },
    arialblack: { nome: 'Arial Black (Archivo Black)', family: 'Archivo Black', weight: 400 },
    futura: { nome: 'Futura Bold (Jost)', family: 'Jost', weight: 800 },
    rubik: { nome: 'Rubik Black Itálico', family: 'Rubik', weight: 900, italic: true },
    roboto: { nome: 'Roboto Bold', family: 'Roboto', weight: 700, texto: true },
    opensans: { nome: 'Open Sans Bold', family: 'Open Sans', weight: 700, texto: true },
    calibri: { nome: 'Calibri (Carlito)', family: 'Carlito', weight: 700, texto: true }
  };
  const PADRAO = { linha1: 'BISCOITO', linha2: 'PIRAQUE', destaque: 'QUEIJINHO', peso: '138g', preco: '5,99', rodape: 'ACIMA DE 2 UNIDADES OU +', topoMm: 70, fTitulo: 'montserrat', fDestaque: 'bebas', fPreco: 'impact', fDetalhe: 'roboto' };
  const form = document.getElementById('campos');
  const printButton = document.getElementById('imprimir');
  const status = document.getElementById('estado');
  const canvas = document.createElement('canvas').getContext('2d');
  const containers = [...document.querySelectorAll('.conteudo')];
  const storageKey = 'encarte-cpanel';
  let dados = { ...PADRAO }, revision = 0, layoutPending = Promise.resolve();
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
    if (saved && typeof saved === 'object') {
      for (const key of Object.keys(PADRAO)) {
        if (key === 'topoMm') dados[key] = Number.isFinite(Number(saved[key])) ? Math.max(0, Math.min(150, Number(saved[key]))) : 70;
        else if (typeof saved[key] === 'string') dados[key] = saved[key];
      }
    }
  } catch (_) { /* Edição funciona mesmo sem armazenamento. */ }
  for (const key of ['fTitulo', 'fDestaque', 'fPreco', 'fDetalhe']) {
    if (!FONTES[dados[key]]) dados[key] = PADRAO[key];
    const select = form.elements.namedItem(key);
    for (const texto of [false, true]) {
      const group = document.createElement('optgroup');
      group.label = texto ? 'Texto' : 'Alto impacto';
      for (const [id, font] of Object.entries(FONTES)) {
        if (Boolean(font.texto) !== texto) continue;
        const option = document.createElement('option'); option.value = id; option.textContent = font.nome; group.append(option);
      }
      select.append(group);
    }
  }
  function syncForm() { for (const [key, value] of Object.entries(dados)) form.elements.namedItem(key).value = value; }
  function fontString(font) { return `${font.italic ? 'italic ' : ''}${font.weight} 100px '${font.family}'`; }
  function measure(text, font) { canvas.font = fontString(font); return canvas.measureText(text || ' ').width; }
  async function render() {
    const current = ++revision;
    const snapshot = { ...dados };
    printButton.disabled = true;
    document.getElementById('topo-valor').textContent = snapshot.topoMm + ' mm';
    document.querySelector('.topo-indicador').style.height = snapshot.topoMm + 'mm';
    const specs = [
      ['linha1', 'fTitulo', 1.6, 1], ['linha2', 'fTitulo', 1.6, 1],
      ['destaque', 'fDestaque', 2.2, 1], ['peso', 'fDetalhe', .6, .35],
      ['preco', 'fPreco', 2.6, 1], ['rodape', 'fDetalhe', .6, .85]
    ];
    const lines = specs.map(([key, fk, weight, fraction]) => ({ key, font: FONTES[snapshot[fk]], weight, fraction, text: key === 'preco' ? 'R$ ' + snapshot.preco : formatarEncarte(snapshot[key]) })).filter(line => line.text.trim());
    try { await Promise.all(lines.map(line => document.fonts.load(fontString(line.font)))); }
    catch (_) { if (current === revision) status.textContent = 'Não foi possível carregar as fontes. Recarregue a página antes de imprimir.'; return; }
    if (current !== revision || !canvas) return;
    const pxMm = 96 / 25.4, height = (297 - snapshot.topoMm - 12) * pxMm, width = 186 * pxMm;
    const caps = {}, sizes = {};
    for (const line of lines) {
      const w = line.key === 'preco' ? measure(snapshot.preco, line.font) + .45 * measure('R$ ', line.font) : measure(line.text, line.font);
      caps[line.key] = width * line.fraction / w * 100;
    }
    let free = [...lines], rest = height;
    while (free.length) {
      const total = free.reduce((sum, line) => sum + line.weight, 0);
      const pinned = free.filter(line => rest * line.weight / total / 1.18 >= caps[line.key]);
      if (!pinned.length) { for (const line of free) sizes[line.key] = rest * line.weight / total / 1.18; break; }
      for (const line of pinned) { sizes[line.key] = caps[line.key]; rest -= sizes[line.key] * 1.18; }
      free = free.filter(line => !pinned.includes(line));
    }
    for (const container of containers) {
      container.style.top = snapshot.topoMm + 'mm'; container.replaceChildren();
      for (const line of lines) {
        const el = document.createElement('div'); el.className = 'linha'; el.dataset.key = line.key;
        el.style.fontFamily = `'${line.font.family}', sans-serif`; el.style.fontWeight = line.font.weight;
        el.style.fontStyle = line.font.italic ? 'italic' : 'normal'; el.style.fontSize = sizes[line.key] + 'px';
        if (line.key === 'peso') el.style.textAlign = 'right';
        if (line.key === 'preco') { const moeda = document.createElement('span'); moeda.className = 'moeda'; moeda.textContent = 'R$ '; el.append(moeda, document.createTextNode(snapshot.preco)); }
        else el.textContent = line.text;
        container.append(el);
      }
    }
    printButton.disabled = false; status.textContent = '';
  }
  function update() {
    try { localStorage.setItem(storageKey, JSON.stringify(dados)); } catch (_) { /* Sem armazenamento, mantém edição e impressão. */ }
    layoutPending = render();
  }
  form.addEventListener('submit', event => event.preventDefault());
  form.addEventListener('input', event => {
    const key = event.target.name;
    if (!(key in PADRAO)) return;
    dados[key] = key === 'topoMm' ? Number(event.target.value) : event.target.value; update();
  });
  document.getElementById('limpar').addEventListener('click', () => {
    dados = { ...PADRAO, topoMm: dados.topoMm, linha1: '', linha2: '', destaque: '', peso: '', preco: '', rodape: '' };
    syncForm(); update();
  });
  printButton.addEventListener('click', async () => { await layoutPending; await document.fonts.ready; if (!printButton.disabled) window.print(); });
  function resize() {
    const available = document.querySelector('.preview').clientWidth;
    document.querySelector('.preview-wrap').style.setProperty('--scale', Math.min(.6, available / (210 * 96 / 25.4)));
  }
  new ResizeObserver(resize).observe(document.querySelector('.preview'));
  syncForm(); resize(); update();
})();
