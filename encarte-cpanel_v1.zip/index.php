<?php
// PHP apenas entrega a página; edição e impressão acontecem no navegador.
header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Encarte de Oferta — Gerador para impressão</title>
<meta name="description" content="Crie encartes A4 com ajuste automático de texto e impressão em preto no papel pré-impresso.">
<meta property="og:title" content="Encarte de Oferta — Gerador para impressão">
<meta property="og:description" content="Cartazes A4 com fontes ajustáveis e texto redimensionado automaticamente.">
<meta property="og:type" content="website"><meta name="twitter:card" content="summary">
<link rel="stylesheet" href="assets/fonts.css"><link rel="stylesheet" href="assets/style.css">
<script src="assets/formatar.js" defer></script><script src="assets/app.js" defer></script>
</head>
<body>
<main class="editor">
<aside><h1>ENCARTE DE OFERTA</h1>
<form id="campos" autocomplete="off">
<label>Linha 1<input name="linha1" value="BISCOITO"></label>
<label>Linha 2<input name="linha2" value="PIRAQUE"></label>
<label>Destaque<input name="destaque" value="QUEIJINHO"></label>
<label>Peso / medida<input name="peso" value="138g"></label>
<label>Preço (sem R$)<input name="preco" value="5,99" inputmode="decimal"></label>
<label>Rodapé<input name="rodape" value="ACIMA DE 2 UNIDADES OU +"></label>
<div class="fontes">
<label>Fonte títulos<select name="fTitulo" aria-label="Fonte títulos"></select></label>
<label>Fonte destaque<select name="fDestaque" aria-label="Fonte destaque"></select></label>
<label>Fonte preço<select name="fPreco" aria-label="Fonte preço"></select></label>
<label>Fonte peso/rodapé<select name="fDetalhe" aria-label="Fonte peso/rodapé"></select></label>
</div>
<label>Altura do topo pré-impresso: <output id="topo-valor">70 mm</output><input name="topoMm" type="range" min="0" max="150" value="70"></label>
<div class="acoes"><button id="imprimir" type="button">IMPRIMIR</button><button id="limpar" type="button">Limpar</button></div>
</form><p id="estado" role="status" aria-live="polite"></p>
<noscript>Ative o JavaScript no navegador para editar e imprimir o encarte.</noscript>
</aside>
<section class="preview" aria-label="Prévia do encarte"><div class="preview-wrap"><div class="folha folha-tela"><div class="topo-indicador">OFERTA (pré-impresso)</div><div class="conteudo"></div></div></div></section>
</main>
<div class="print-only"><div class="folha"><div class="conteudo"></div></div></div>
</body></html>
